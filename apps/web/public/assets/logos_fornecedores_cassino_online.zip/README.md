# Logos de fornecedores de jogos para cassino online

Este pacote reúne os logos solicitados em uma pasta única. Alguns arquivos foram obtidos diretamente de páginas oficiais; outros são candidatos visuais localizados em busca de imagens quando o asset oficial direto não estava publicamente exposto.

**Observação importante:** estes logos são marcas registradas de suas respectivas empresas. O uso em sites, materiais comerciais ou integrações deve respeitar as diretrizes de marca, termos de uso e autorizações aplicáveis de cada titular.

| Empresa | Arquivo | Observação |
|---|---|---|
| Pragmatic Play | `pragmatic_play.svg` | Fonte oficial. Logo branco, melhor em fundo escuro. |
| Evolution | `evolution.svg` | Fonte oficial. Logo SVG principal. |
| Playtech | `playtech.png` | PNG de logo completo; usado como alternativa após bloqueio temporário do download via Wikimedia. |
| NetEnt | `netent.png` | PNG de logo completo; não consegui obter asset oficial direto sem login/brand kit. |
| Microgaming | `microgaming.svg` | Fonte oficial. Ícone/mark em SVG. |
| Red Tiger | `red_tiger.png` | PNG de logo completo; asset oficial direto não ficou exposto publicamente. |
| Nolimit City | `nolimit_city.png` | Fonte oficial via imagem de metadados; PNG. |
| Yggdrasil | `yggdrasil.png` | PNG de logo completo. Página oficial tem trademark guidelines, mas download direto não ficou exposto no texto extraído. |
| Play'n GO | `playngo.png` | PNG com logo colorido; alternativa ao PNG branco do Wikimedia. |
| Hacksaw Gaming | `hacksaw_gaming.png` | PNG do logo em área clara; proveniente do site oficial nos resultados de imagem. |
